# Historical Sources

References to historical data or scholarship mentioned in archives:

- **ChatGPT:** Jajce fall, Doboj stress test, Recruitment and Manpower 1991-1995; Balkan Battlegrounds; historical order of battle.
- **Claude:** JNA garrison locations; municipality adjacencies for “historical” flip cascades; Bosnia 1991-1995 strategy simulation audit.

No single curated list of historical sources is present in the raw conversations; this folder is for future collation of cited historical sources.
