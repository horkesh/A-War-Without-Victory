# Fragmentation and Command Friction

- **ChatGPT:** Command capacity & friction; fragmentation requires authority collapse + connectivity disruption; reunification/fragmentation multi-turn (Engine Invariants §7).
- **Claude:** Command hierarchy (Corps/Brigade) in “Game creation project”; audit searched design for fragmentation.

**Canon:** Engine Invariants §7 — fragmentation concurrent authority collapse and connectivity disruption; one-turn fragmentation/reunification invalid.

**Raw refs:** `2026-01-22_chatgpt_Bosnia_War_Simulation_Design.md`, Claude Code review, Bosnia 1991-1995 audit.
